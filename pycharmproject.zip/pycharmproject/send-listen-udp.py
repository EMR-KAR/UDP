
import socket
BUFF_SIZE = 65536
server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_RCVBUF, BUFF_SIZE)
server_socket.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR, 1)
#host_name = socket.gethostname()
host_ip = "0.0.0.0"  # socket.gethostbyname(host_name)
print(host_ip)
port = 3131
socket_address = (host_ip, port)
#target_address = ("192.168.10.5", 3131)
server_socket.bind(socket_address)
while True:
    packet, _ = server_socket.recvfrom(BUFF_SIZE)
    print(packet)
    #server_socket.sendto(packet, target_address)
