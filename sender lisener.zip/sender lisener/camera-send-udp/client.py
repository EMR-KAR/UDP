# This is client code to receive video frames over UDP
import cv2, imutils, socket
import numpy as np
import time
import base64

BUFF_SIZE = 65536
client_socket = socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
client_socket.setsockopt(socket.SOL_SOCKET,socket.SO_RCVBUF,BUFF_SIZE)
host_name = socket.gethostname()
host_ip = 'localhost'#  socket.gethostbyname(host_name)
print(host_ip)
port = 3131

client_socket.bind((host_ip,port))

message = b'Hello'

test = b''

count = 0

#client_socket.sendto(message,(host_ip,port))
fps,st,frames_to_count,cnt = (0,0,20,0)
while True:
	packet,_ = client_socket.recvfrom(BUFF_SIZE)
	
	print('received byte : ')
	print(len(packet))
	
	test += packet

	count+=1

	if(count == 4):
		count = 0

		data = base64.b64decode(test+ b'=' * (-len(test) %3))
		npdata = np.fromstring(data,dtype=np.uint8)
		frame = cv2.imdecode(npdata,1)
		
		cv2.imshow("RECEIVING VIDEO",frame)
			
		test = b''


	# data = base64.b64decode(packet,' /')
	# npdata = np.fromstring(data,dtype=np.uint8)
	# frame = cv2.imdecode(npdata,1)
	# frame = cv2.putText(frame,'FPS: '+str(fps),(10,40),cv2.FONT_HERSHEY_SIMPLEX,0.7,(0,0,255),2)
	# cv2.imshow("RECEIVING VIDEO",frame)
	key = cv2.waitKey(1) & 0xFF
	if key == ord('q'):
		client_socket.close()
		break
	if cnt == frames_to_count:
		try:
			fps = round(frames_to_count/(time.time()-st))
			st=time.time()
			cnt=0
		except:
			pass
	cnt+=1

	#try:
	#	packet,_ = client_socket.recvfrom(BUFF_SIZE)

	#	#print(len(packet))

	#	#print(packet)
		
	#	test += packet

	#	cnt+=1

	#	if(cnt == 4):
	#		cnt = 0
	#		print((test));
	#		data = base64.b64decode(test,' /')
	#		npdata = np.fromstring(data,dtype=np.uint8)
	#		test = cv2.imdecode(npdata,1)
			
	#		cv2.imshow("RECEIVING VIDEO",test)
			
	#		test = b''

		

	#except:
	#	print("salak")
	
	

	
	

